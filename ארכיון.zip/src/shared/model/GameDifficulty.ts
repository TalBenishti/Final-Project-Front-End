export enum GameDifficulty {
    Hard = 'hard',
    Medium = 'medium',
    Easy = 'easy',
  }
  