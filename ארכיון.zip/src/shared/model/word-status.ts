export enum WordStatus {
    Normal = 'normal',
    Selected = 'selected',
    Disabled = 'disabled',
  }